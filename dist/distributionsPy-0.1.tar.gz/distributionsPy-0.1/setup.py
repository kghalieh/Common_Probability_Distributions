from setuptools import setup

setup(name='distributionsPy',
      version='0.1',
      description='Common Probability Distributions',
      packages=['distributionsPy'],
	  author = 'Karam abughalieh',
	  author_email = 'karam2688@gmail.com',
      zip_safe=False)
